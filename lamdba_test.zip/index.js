
 console.log('Loading...');

var config = require("./config");
var mysql= require('mysql');

exports.handler = function(event, context) {
	console.log('OK lets do this');
       
    var sql;
    
    // pass posttype: 0 = unverified; 1 = verified
    var posttype = event.posttype;
    var collaboratorid = event.collaboratorid;
    
	var conn = mysql.createConnection({
	    host      :  config.DATABASE.HOST, 
	    user      :  config.DATABASE.USERNAME, 
	    password  :  config.DATABASE.PASSWORD,
	    database  :  config.DATABASE.DB
	});
	conn.connect(function(err) {   
	    if (err) {
		    console.error('error connecting: ' + err.stack);
		    return;
		}
		console.log('connected id ' + conn.threadId);
	});
	

    sql='update ckic_tbl_stages set verified = "' + posttype  + '" where id = ' + collaboratorid;
	
    console.log('sql statement: ' + sql);
	
	var result =conn.query ( sql, function(error, rows, fields){ 
	    if (error) {
	        console.log(error.message);  	
	    } 
	    else {
	        context.succeed(rows);
	    }
	});
}