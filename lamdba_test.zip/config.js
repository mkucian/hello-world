module.exports = {
	DATABASE: {
		DB: "CKIC01",
		USERNAME: "chris",
		PASSWORD: "Bananaman1",
		HOST: "ckaurora01c1.cluster-ro-cchpk7oonpro.eu-west-1.rds.amazonaws.com" //rds endpoint
	}
}